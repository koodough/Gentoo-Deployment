#!/bin/bash
java -Xmx1024M -Xms512M -cp Minecraft.jar net.minecraft.LauncherFrame
